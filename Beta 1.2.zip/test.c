
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include<unistd.h>


int OS=2;
void ClearScreen(){
    if (OS==1) system("cls");
    if(OS==2) system("clear");
}


void ThankYouPage() {

       ClearScreen();

    printf("\033[96m***************************************************************************\n");
    printf("*                                                                         *\n");
    printf("* \033[33m  _______                 _    _    _   ____   _______  ______  _       \033[96m*\n");
    printf("* \033[33m |__   __|    /\\         | |  | |  | | / __ \\ |__   __||  ____|| |      \033[96m*\n");
    printf("* \033[33m    | |      /  \\        | |  | |__| || |  | |   | |   | |__   | |      \033[96m*\n");
    printf("* \033[33m    | |     / /\\ \\   _   | |  |  __  || |  | |   | |   |  __|  | |      \033[96m*\n");
    printf("* \033[33m    | |    / ____ \\ | |__| |  | |  | || |__| |   | |   | |____ | |____  \033[96m*\n");
    printf("* \033[33m    |_|   /_/    \\_\\ \\____/   |_|  |_| \\____/    |_|   |______||______| \033[96m*\n");
    printf("*                                                                         *\n");
    printf("*                  \033[91m Thank you for visiting the Taj Hotel!   \033[96m              *\n");
    printf("*                                                                         *\n");
    printf("***************************************************************************\n\n");


    for (int i = 0; i <= 20; i++) {
        int percentage = (i * 100) / 20;
        int progress = (i * 39) / 20;

        printf(YELLOW"\r             || ");
        for (int j = 0; j < 39; j++) {
            if (j <= progress) {
                printf("\u2588");
            } else {
                printf(" ");
            }
        }
        printf(" || %d%%", percentage);

        fflush(stdout);
        usleep(100000); // Simulate progress delay
    }

    printf("\n\n\033[95m    Goodbye from the Taj Hotel! See you again soon! \033[33m\n\n\n\n");
    usleep(1000000); // Pause for dramatic effect



}


int main (){
    ThankYouPage();
    return 0;
}