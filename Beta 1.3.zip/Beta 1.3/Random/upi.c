#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <qrencode.h>

void generateUPIQRCode(const char *vpa, const char *name, const char *amount) {
    // Build the UPI string
    char upi_url[512];
    snprintf(upi_url, sizeof(upi_url), 
             "upi://pay?pa=%s&pn=%s&am=%s&cu=INR", 
             vpa, name, amount);
    printf("UPI URL: %s\n", upi_url);

    // Generate QR code
    QRcode *qrcode = QRcode_encodeString(upi_url, 0, QR_ECLEVEL_L, QR_MODE_8, 1);
    if (qrcode == NULL) {
        fprintf(stderr, "Failed to generate QR Code\n");
        return;
    }

    // Print QR code to terminal as ASCII
    for (int y = 0; y < qrcode->width; y++) {
        for (int x = 0; x < qrcode->width; x++) {
            printf((qrcode->data[y * qrcode->width + x] & 1) ? "██" : "  ");
        }
        putchar('\n');
    }

    // Free memory
    QRcode_free(qrcode);
}

int main() {
    const char *vpa = "aryansharma0305@okaxis";
    const char *name = "Aryan Sharma";
    char amount[16];

    printf("Enter the amount: ");
    scanf("%15s", amount);

    generateUPIQRCode(vpa, name, amount);

    return 0;
}
