#include "ui.h"

int main(void) {
    Menu *menuHead = loadMenu();
    Tables *tablesHead = loadTables();
    OrderHistory *orderHistoryHead = loadOrderHistory();
    CurrentOrders *currentOrdersHead = loadCurrentOrders();

    OsSelectionPage(PASSHEADS);
    // SalesAnalysisPage(PASSHEADS);

    deleteMenu(menuHead);
    deleteTables(tablesHead);
    deleteOrderHistory(orderHistoryHead);
    deleteCurrentOrders(currentOrdersHead);

    return 0;
}
